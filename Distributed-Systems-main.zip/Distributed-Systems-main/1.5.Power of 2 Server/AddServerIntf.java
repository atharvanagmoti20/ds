import java.rmi.*;
public interface AddServerIntf extends Remote { 
//method declaration 
double pwr(double d1) throws RemoteException;
}
